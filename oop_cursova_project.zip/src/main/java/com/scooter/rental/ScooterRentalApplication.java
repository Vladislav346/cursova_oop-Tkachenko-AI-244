package com.scooter.rental;
public class ScooterRentalApplication {
 public static void main(String[] args) {}
}